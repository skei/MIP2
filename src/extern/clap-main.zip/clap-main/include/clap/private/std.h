#pragma once

#ifdef __cplusplus
#   include <cstdint>
#   include <cstddef>
#else
#   include <stddef.h>
#   include <stdbool.h>
#   include <stdint.h>
#   include <stdalign.h>
#endif