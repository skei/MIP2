#pragma once

#include "private/std.h"

#ifdef __cplusplus
extern "C" {
#endif

enum {
   CLAP_NAME_SIZE = 256,
   CLAP_MODULE_SIZE = 512,
   CLAP_KEYWORDS_SIZE = 256,
   CLAP_PATH_SIZE = 4096,
};

#ifdef __cplusplus
}
#endif
